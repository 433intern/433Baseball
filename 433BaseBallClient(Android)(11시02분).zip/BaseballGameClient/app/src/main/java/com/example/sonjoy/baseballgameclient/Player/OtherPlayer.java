package com.example.sonjoy.baseballgameclient.Player;

/**
 * Created by Sonjoy on 2015-12-13.
 */
public class OtherPlayer {
}
